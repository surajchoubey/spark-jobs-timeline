package org.apache.spark.sql.execution.ui.zetta

import org.apache.spark.JobExecutionStatus
import org.apache.spark.internal.Logging
import org.apache.spark.sql.execution.ui.{SQLPlanMetric, SparkPlanGraph}
import org.apache.spark.ui.{UIUtils, WebUIPage}

import javax.servlet.http.HttpServletRequest
import scala.collection.mutable.ArrayBuffer
import scala.xml.{Elem, Node}

class OperatorPage(parent: ZSQLTab) extends WebUIPage(prefix="execution") with Logging {

  private val sqlStore = parent.sqlStore

  override def render(request: HttpServletRequest): Seq[Node] = {
    val parameterExecutionId = request.getParameter("id")
    require(parameterExecutionId != null && parameterExecutionId.nonEmpty,
      "Missing execution id parameter")

    val executionId = parameterExecutionId.toLong

    val content = sqlStore.execution(executionId).map { executionUIData =>

      // TODO: summary preparation
      // summary will contains
      // completion time, and all completed stage links

      val summary =
        <div>
          <h2>this is summary</h2>
        </div>

      // TODO: metrics data
      // this will be a table



      val operatorMetricHTML =
          <div>
            <h2>Operator data</h2>
            <p id="csvdata">{getOperatorMetricFormatted(executionId)}</p>
          </div>


      // TODO: metrics visualization
      // this will be pi-chart or similar viz

      // stage metric data
      val stageMetricContent = getStageMetricData(executionUIData.stages.toArray)

      val stageMetricHTML =
        <div>
          <h2>Stage data</h2>
          <p>{stageMetricContent}</p>
        </div>

      val metricsUI =
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8 col-sm-12" id="chart"></div>
          </div>
        </div>

      val jsConnect =
        <script
          type="module"
          src="http://127.0.0.1:5500/zoomable-sunburst-spark-profiler/index.js"
        >
        </script>

      summary ++ metricsUI ++ operatorMetricHTML ++ stageMetricHTML ++ jsConnect

    }.getOrElse {
      <div>No information to display for query {executionId}</div>
    }



    UIUtils.headerSparkPage(
      request, s"Details for Query $executionId", content, parent)
  }

  private def getOperatorMetricFormatted(executionId: Long): String = {
    val graph = sqlStore.planGraph(executionId)
    val metricValues = sqlStore.executionMetrics(executionId)
    val operatorMetrics = OperatorMetric.getOperatorMetrics(graph, metricValues)

    var metricContent = ""
    for (operatorMetric <- operatorMetrics)
      metricContent += s"$operatorMetric|"

    metricContent
  }

  private def getStageMetricData(stages: Array[Int]): String = {
    val data = parent.appStatusStore

    val stagesMetric = new Array[StageMetric](stages.length)
    var stageMetricContent = ""
    for (i <- 0 to stages.length-1) {
      stagesMetric(i) = StageMetric.create(data, stages(i))
      stageMetricContent += stagesMetric(i).toString
    }

    stageMetricContent
  }
}
