export const treeMaker = async (line) => {

  const splitOne = line.split("|");
  const splitTwo = [];

  for (const item of splitOne) {
    if (item === "") continue;
    const temp = item.split(",");
    splitTwo.push(temp);
  }

  let tree = {
    name: "driver",
    children: [],
  };

  let currentNode = tree;

  const treeNode = (_name) => {
    return {
      name: _name,
      children: [],
    };
  };

  for (const traversal of splitTwo) {
    const N = traversal.length;
    currentNode = tree;

    for (let index = 1; index <= N - 2; index++) {
      if (currentNode.name === "") throw new Error("Nameless Tree Node!");

      const C = currentNode.children.length;
      let childFound = false;

      for (let i = 0; i < C; i++) {
        if (currentNode.children[i].name === traversal[index]) {
          currentNode = currentNode.children[i];
          childFound = true;
          break;
        }
      }

      if (childFound) continue;

      currentNode.children.push(treeNode(traversal[index]));

      currentNode = currentNode.children[currentNode.children.length - 1];
      if (index === N - 2) {
        currentNode.value = traversal[N - 1];
        delete currentNode.children;
      }
    }
  }

  // console.log(tree);

  return tree;
};
