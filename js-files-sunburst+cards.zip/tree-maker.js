export const treeMaker = async (line) => {

  const splitOne = line.split("|");
  const splitTwo = [];
  const tableMetrics = [];

  for (const item of splitOne) {
    if (item === "") continue;
    const temp = item.split(",");
    splitTwo.push(temp);
  }

  let tree = {
    name: "driver",
    children: [],
  };

  let currentNode = tree;

  const treeNode = (_name) => {
    return {
      name: _name,
      children: [],
    };
  };

  for (const traversal of splitTwo) {
    const N = traversal.length;
    currentNode = tree;

    for (let index = 1; index <= N - 2; index++) {
      if (currentNode.name === "") throw new Error("Nameless Tree Node!");

      const C = currentNode.children.length;
      let childFound = false;

      for (let i = 0; i < C; i++) {
        if (currentNode.children[i].name === traversal[index]) {
          currentNode = currentNode.children[i];
          childFound = true;
          break;
        }
      }

      if (childFound) continue;

      currentNode.children.push(treeNode(traversal[index]));

      currentNode = currentNode.children[currentNode.children.length - 1];
      if (index === N - 2) {
        currentNode.value = traversal[N - 1];
        delete currentNode.children;

        tableMetrics.push(currentNode)
      }
    }
  }

  return { tableMetrics, tree };
};

export const HTMLtableMaker = (tableMetrics) => {
  var table = document.createElement('table');
  table.className = 'table table-striped';

// create table head/body
  var thead = document.createElement('thead');
  var tbody = document.createElement('tbody');

  var TR = document.createElement('tr');
  ['Process', 'Time Taken'].forEach(heading => {
    var tableheading = document.createElement('th');
    tableheading.setAttribute('scope', 'col');
    tableheading.innerText = heading;
    TR.appendChild(tableheading);
  })
  thead.appendChild(TR);

  let i = 1;

  tableMetrics.forEach(entry => {
    var entryRow = document.createElement('tr');
    var TH = document.createElement('th');
    var td1 = document.createElement('td');
    var td2 = document.createElement('td');

    // TH.setAttribute('scope', 'row');
    TH.innerText = i++;

    td1.innerText = entry.name;
    td2.innerText = entry.value;

    // entryRow.appendChild(TH);
    entryRow.appendChild(td1);
    entryRow.appendChild(td2);

    tbody.appendChild(entryRow);
  })

  table.appendChild(thead);
  table.appendChild(tbody);

  return table;

}

export const stagesDataMaker = async (line) => {

  const stages = line.split('|')
  const result = [];
  console.log(line);

  for (const stage of stages) {
      if (stage === '') continue;
      const splitTwo = stage.split(';');
      const stageData = splitTwo[0];
      const stageDataSplits = stageData.split(',');

      const stageFields = ['name', 'date', 'duration', 'starttime', 'endtime' ];

      let stageItem = {};

      for (const [index, stageDataSplit] of stageDataSplits.entries()) {
          if (stageDataSplit === '') continue;
          stageItem[stageFields[index]] = stageDataSplit;
      }

      const tasks = splitTwo[1].split(':');
      const tasksArray = [];
      const taskFields = ['task','start','end','duration'];

      for (const [index, task] of tasks.entries()) {
          if (task === '') continue;
          const eachTask = task.split(',');
          let taskItem = {};

          taskItem[taskFields[0]] = eachTask[0];
          taskItem[taskFields[1]] = eachTask[1];
          taskItem[taskFields[2]] = eachTask[2];
          taskItem[taskFields[3]] = eachTask[3];

          tasksArray.push(taskItem);
      }

      result.push({
          ...stageItem,
          children: tasksArray
      })

  }
  console.log(result);
  return result;
}
