const BGCOLOR = "#2fc418";

const createCardForStage = (stage) => {
  // card
  const card = document.createElement("div");
  card.className = "card shadow";
  card.style = "margin: 10px; width: 18rem; padding: 10px";

  // card-body
  const body = document.createElement("div");
  body.className = "card-body";

  // title
  let h5 = document.createElement("h5");
  h5.textContent = stage.task;
  body.appendChild(h5);

  // description
  let p = document.createElement("p");
  p.className = "card-text";
  p.textContent = stage.task;
  body.appendChild(p);

  // icons and details
  let i = 0;
  let eta = `${stage.end - stage.start} s`;

  /*
  const fas_text = [
    stage.task,
    eta,
    stage.rows,
    stage.read,
    stage.write,
  ];
  const fas = [
    "fa fa-tasks",
    "fa fa-clock-o",
    "fa fa-bars",
    "fa fa-book",
    "fa fa-pencil-square-o",
  ];

  fas.forEach((fa) => {
    let detail = document.createElement("i");
    detail.className = fa;
    detail.ariaHidden = true;
    detail.textContent = " " + fas_text[i++];

    body.appendChild(detail);
    body.appendChild(document.createElement("br"));
  });
  */

  // progress-bar
  const progress = document.createElement("div");
  progress.className = "progress";

  const progress_bar = document.createElement("div");
  progress_bar.id = stage.name;
  progress_bar.className = "progress-bar";
  progress_bar.setAttribute("role", "progressbar");
  progress_bar.setAttribute(
    "style",
    `width: ${50}%; background-color: ${BGCOLOR};` // TODO: edit percentage here
  );
  progress_bar.setAttribute("aria-valuenow", `${stage.duration}`);
  progress_bar.setAttribute("aria-valuemin", "0");
  progress_bar.setAttribute("aria-valuemax", "100");
  progress_bar.textContent = /*stage.duration*/ "50 %"; // TODO: edit percentage here

  progress.appendChild(progress_bar);

  card.appendChild(body);
  card.appendChild(progress);

  return card;
};

export const renderCards = (stages) => {
  
  const stagesContainer = document.querySelector("#timeprogress");
  stagesContainer.innerText = "";

  stages.forEach(stage => {
    const card = createCardForStage(stage);
    stagesContainer.appendChild(card);
  });

};